def test_get_sklearn_version():
    assert True
